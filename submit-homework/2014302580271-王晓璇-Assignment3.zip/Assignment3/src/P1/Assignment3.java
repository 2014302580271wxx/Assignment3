package P1;

import java.io.File;
import java.io.IOException;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;
import org.jsoup.*;
import java.util.regex.*;
import java.lang.*;
import java.sql.*;
import java.sql.Connection;
import java.util.*;


public class Assignment3 extends Thread {
	//�������ݿ�
	public void mySql(String s1,String s2,String s3,String s4) {
		String url1="jdbc:mysql://localhost:3306/test";
		String userName="root";
		String password="580271";
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url1,userName,password);
			Statement st=con.createStatement();
			String sql="INSERT INTO teacher(����,���,�о�����,����)VALUES('"+s1+"','"+s2+"','"+s3+"','"+s4+"')";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
		}catch(ClassNotFoundException ce) {
			System.out.println("δ�ҵ�������");
			ce.printStackTrace();
		}catch(SQLException se) {
		    System.out.println("���ݿ�����ʧ�ܣ�");
			se.printStackTrace();
		}
	}
	
	public void getInfomation() {
		Assignment3 a3=new Assignment3();
	
		//��ȡ��ʦ��ҳ
				String url="http://www.wpi.edu/academics/cs/research-interests.html";
				HttpRequest request=HttpRequest.get(url);
				System.out.println(request.toString());
					
				String FileName="Teacher.html";
				request.receive(new File(FileName));
				
				try
				{
				File file1=new File("Teacher.html");
				Document doc=Jsoup.parse(file1,"UTF-8",url);
				
				//��ȡurl
				Elements ele=doc.getElementsByClass("half");
				Elements links=ele.select("a");
				
				String name=null;
				String text=null;
				String text1=null;
				String mail=null;
				String research=null;
				for(Element link:links) {
					String linkHref=link.attr("href");
					
					//��ȡ������ҳ
					HttpRequest response=HttpRequest.get(linkHref);
					System.out.println(response.toString());
					String fn="TeacherOne.html";
					response.receive(new File(fn));
					
					//��ȡ����
					File f=new File("TeacherOne.html");
					Document doc1=Jsoup.parse(f,"UTF-8",linkHref);
					Elements conment=doc1.getElementsByTag("h2");
					name=conment.text();
					
					//���
					Elements info=doc1.getElementsByClass("titles");
					text=info.text();
					
					//��ȡ����
					Element mailinfo=doc1.getElementById("contactinfo");
					text1=mailinfo.text();
					Pattern pattern=Pattern.compile("\\w+@(\\w+.)+[a-z]{3,3}");
					Matcher matcher=pattern.matcher(text1);
					while(matcher.find()) {
						mail=matcher.group();
					}
					
					//��ȡ�о�����
					Elements e1=doc1.getElementsByClass("col");
					research=e1.text().replaceAll(" ","\r\n");
					
					//�������ݿ�
					a3.mySql(name,text, research, mail);
					
				}
				}catch(IOException e) {
					e.printStackTrace();
				}
	}
		
	public static void main(String[] args) {
		
		Assignment3 a3=new Assignment3();
		
		//��¼���߳̿�ʼʱ��
		long singleStartTime=System.currentTimeMillis();
		a3.getInfomation();
		//��¼���߳̽���ʱ��
		long singleEndTime=System.currentTimeMillis();
		//���߳�����ʱ��
		System.out.println("���̺߳�ʱ:"+(singleEndTime-singleStartTime)+"ms");
		
		//��¼���߳̿�ʼʱ��
		long multiStartTime=System.currentTimeMillis();
		//���ö��߳�
		Thread t1=new Thread();
		Thread t2=new Thread();
		Thread t3=new Thread();
		a3.getInfomation();
		t1.start();
		t2.start();
		t3.start();
		//��¼���߳̽���ʱ��
		long multiEndTime=System.currentTimeMillis();
		System.out.println("���̺߳�ʱ��"+(multiEndTime-multiStartTime)+"ms");
		
		
	}

}
